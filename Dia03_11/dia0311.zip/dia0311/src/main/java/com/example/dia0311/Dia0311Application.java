package com.example.dia0311;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dia0311Application {

	public static void main(String[] args) {
		SpringApplication.run(Dia0311Application.class, args);
	}

}
