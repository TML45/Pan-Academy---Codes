package com.example.consulta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultaApplicationTests {

	@Test
	void contextLoads() {
	}

}
